<?php
$conn = mysqli_connect("localhost","root","","br_shope")
or die("Could not Connect to Database");
?>